from controller import Controller

def Main():
    c = Controller()
    c.run()

if __name__ =="__main__":
    Main()