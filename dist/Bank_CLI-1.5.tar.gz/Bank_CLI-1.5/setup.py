from setuptools import setup

setup(name='Bank_CLI',
	version = '1.5',
	description='A command line intepretation of a bank',
	packages=['Bank'],
	author = 'Nifesimi Ademoye',
	author_email= 'nifesimifrank@gmail.com',
	zip_safe=False)